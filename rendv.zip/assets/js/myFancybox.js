



$(document).ready(function () {
  $(".fancybox").fancybox({
  });
});

$.fancybox.defaults.closeExisting = true;